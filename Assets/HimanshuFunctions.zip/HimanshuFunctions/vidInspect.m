%A set of functions which can be used to manipulate videos.
% Copyright (C) 2015 Himanshu Kattelu <himanshu.kattelu@stonybrook.edu>,
% Created : 15-June-2015
% Last Modified : 3-August-2015
% Requires vl_feat for HOG and SIFT

classdef vidInspect
    %vidInspect A set of functions which can be used to manipulate videos.
    %
    %Specifically, these functions can be used to compare videos or clips
    %as well as images. They can also be used to create mappings between
    %video frames to compare.
    %
    %vidInspect Properties:
    %    FFmpegBin - Pathname of ffmpeg/bin. Can be left as ffmpeg if ffmpeg is an environment variable.
    %
    %vidInspect Methods:
    %    clipVid - Takes an input file and and cuts out a clip at the given times
    %    extractFrames - Extracts all frames from a video and places them into a cell array
    %    findOptCover - A version of getMap that uses dynamic time warping to run faster and more accurately
    %    getBounds - Returns the start and end frames of a clip as images
    %    getCloseness - Compares two images and returns a number to represent the closeness
    %    getClosenessR - Does the same thing as getCloseness but assumes the two img have the same resolution (speeds up the computation)
    %    getMap - Maps the shot boundaries in the video to frames in the clip
    %    getMatchPoint - Does the same thing as the getMatchpointsR, except with only one frame to a set of frames
    %    getMatchPoints - Finds the start and end frames that the clip is located at inside the video.
    %    getMatchPointsR - Does the same as the getMatchPoints, except with the frames themselves
    %    getPaths - Extracts all frames from a video then returns a cell array with all pathnames
    %    getRanks - Creates a vector containing the Closeness values of frame when compared to every frame in setOfFrames
    %    getSMap - Gets a matrix where the i,j'th element is (1 - Closeness(clipBnds(i),vidBnds(j)).
    %    max_matrix - Returns the max element of a 2D matrix and it's indices
    %    reverseMap - Maps every frame in the video to those in clip.
    
    properties (Constant)
        %Pathname of ffmpeg/bin. Can be left as ffmpeg if ffmpeg is an environment variable.
        FFmpegBin = 'ffmpeg'
    end
    
    
    methods (Static)
        
        function [val, x, y] = max_matrix(A)
            %max_matrix Returns the max element of a 2D matrix and it's indices
            
            [v, x1] = max(A);
            [val, y] = max(v);
            x = x1(y);
        end
        
        function clipVid(start,finish,input,output)
            %clipVid Takes an input file and and cuts out a clip at the given times
            %Puts the clip into an output file of a specified name
            
            cmd = [vidInspect.FFmpegBin ' -i ' input ' -ss ' num2str(start) ' -to ' num2str(finish) ' ' output];
            system(cmd);
        end
        
        function Closeness = getCloseness(im1x,im2x,cellsize)
            %getCloseness Compares two images and returns a number to represent the closeness
            %Takes in two images, converts them to the same resolution, then returns
            %their closeness.
            %im1x,im2x are images
            %cellsize is the precision of the HOG descriptor (The lower, the more precise)
            
            d1 = size(im1x);
            d2 = size(im2x);
            resolutionH = min([d1(1) d2(1)]);
            resolutionW = min([d1(2) d2(2)]);
            
            %Getting the two images ready
            im1r=imresize(im1x,[resolutionW,resolutionH]);
            im2r=imresize(im2x,[resolutionW,resolutionH]);
            
            %Converts images to singles for the HOG
            im1=im2single(im1r);
            im2=im2single(im2r);
            
            %Getting the HOGS
            hog1 = vl_hog( im1, cellsize, 'verbose');
            hog2 = vl_hog( im2, cellsize, 'verbose');
            
            %Computes and prints the Closeness
            ClosenessM = (abs(abs(hog2) - abs(hog1)));
            Closeness = mean(ClosenessM(:));
        end
        
        function Closeness = getClosenessR(im1x,im2x,cellsize)
            %getClosenessR Does the same thing as getCloseness but assumes the two img have the same resolution (speeds up the computation)
            
            %Converts images to singles for the HOG
            im1=im2single(im1x);
            im2=im2single(im2x);
            
            %Getting the HOGS
            hog1 = vl_hog( im1, cellsize, 'verbose');
            hog2 = vl_hog( im2, cellsize, 'verbose');
            
            %Computes and prints the Closeness
            ClosenessM = (abs(abs(hog2) - abs(hog1)));
            Closeness = mean(ClosenessM);
            
        end
        
        function Bounds = getBounds(clip,res)
            %getBounds Returns the start and end frames of a clip as images
            A = VideoReader(clip);
            cmdStart = [vidInspect.FFmpegBin ' -i ' clip ' -s ' res ' -r 1 -vframes 1 start.jpg'];
            cmdEnd = [vidInspect.FFmpegBin ' -i ' clip ' -s ' res ' -r 1 -vframes 1 -ss ' num2str(A.Duration - 0.1) ' end.jpg'];
            system(cmdStart);
            system(cmdEnd);
            
            Bounds{1} = imread('start.jpg');
            Bounds{2} = imread('end.jpg');
            delete('start.jpg','end.jpg');
        end
        
        function Im = extractFrames(video,fps,res)
            %extractFrames Extracts all frames from a video and places them into a cell array
            %resolution should be written as string in format 'WxH'
            % WARNING: If there are too many frames you may run out of memory.
            
%             if nargin == 3
%               outDir = '';
%             elseif nargin == 4
%               outDir = [outDir '/'];
%             end
            
            cmd = [vidInspect.FFmpegBin ' -i ' video ' -r ' num2str(fps) ' -s ' res  ' image%5d.jpg'];
            system(cmd);
            f = dir('*.jpg');
            files = {f.name};
            Im = cell(numel(files),1);
            for k = 1:numel(files)
                Im{k} = imread(files{k});
                delete(files{k});
            end
            
        end
        
        function imFiles = getPaths(video,fps,res)
            %getPaths Extracts all frames from a video into the folder and then returns a cell array with all pathnames
            cmd = [vidInspect.FFmpegBin ' -i ' video ' -r ' num2str(fps) ' -s ' res  ' image%5d.jpg'];
            system(cmd);
            f = dir('image*');
            imFiles = {f.name};
        end
        
        function Imranks = getRanks(frame,setOfFrames)
            %getRanks Creates a vector containing the Closeness values of frame when compared to every frame in setOfFrames
            Imranks = ones([1,numel(setOfFrames)]);
            for k = 1:numel(setOfFrames)
                Imranks(k) = vidInspect.getCloseness(frame,setOfFrames{k},4);
            end
        end
        
        function [startFrameMatch,endFrameMatch] = getMatchPoints(clip,video,resW,resH,fps)
            %getMatchPoints Finds the start and end frames that the clip is located at inside the video.
            %you can specifiy the fps that you want the video to be
            %read with, as well as the resolution to compare the two.
            
            res = [num2str(resW) 'x' num2str(resH)];
            X = vidInspect.getBounds(clip,res);
            Im = vidInspect.extractFrames(video,fps,res);
            
            X1 = vidInspect.getRanks(X{1},Im);
            X2 = vidInspect.getRanks(X{2},Im);
            
            [~,startFrameMatch] = min(X1);
            [~,endFrameMatch] = min(X2);
            
        end
        
        function [startFrameMatch,endFrameMatch] = getMatchPointsR(clipFrames,vidFrames)
            %getMatchPointsR Does the same as the getMatchPoints, except with the frames themselves
            
            X1 = vidInspect.getRanks(clipFrames{1},vidFrames);
            X2 = vidInspect.getRanks(clipFrames{end},vidFrames);
            
            [~,startFrameMatch] = min(X1);
            [~,endFrameMatch] = min(X2);
            
        end
        
        function point = getMatchPoint(frame,videoFrames)
            %getMatchPoint Does the same thing as the getMatchpointsR, except with only one frame to a set of frames
            X = vidInspect.getRanks(frame,videoFrames);
            [~,point] = min(X);
        end
        
        function Map = getMap(vidFrames,clipFrames,clipShotBnds,vidShotBnds)
            %getMap Maps the shot boundaries in the video to frames in the clip
            %The left column of the output shows the shot boundaries, and the
            %The right column shows the respective match in the clip
            %input the shot boundaries as a row matrix  in increasing order
            matches = zeros(1,numel(clipShotBnds));
            numBounds = numel(vidShotBnds);
            vidShotBnds = num2cell(vidShotBnds);
            vidShotFrames = cell(1,numBounds);
            for k = 1:numBounds
                vidShotFrames{k}  = vidFrames{vidShotBnds{k}};
            end
            
            for k = 1:numel(clipShotBnds)
                clipFrame = clipFrames{clipShotBnds(k)};
                matchpt = vidInspect.getMatchPoint(clipFrame,vidShotFrames);
                matches(k) = vidShotBnds{matchpt};
            end
            
            %             startMatch = vidInspect.getMatchPoint(clipFrames{1},vidFrames,resW,resH,1);
            %             endMatch = vidInspect.getMatchPoint(clipFrames{end},vidFrames,resW,resH,1);
            %
            %             matches = [1; startMatch ; transpose(matches) ; endMatch; numel(vidFrames)];
            %             bounds = [NaN ;1 ;transpose(clipShotBnds) ;numel(clipFrames);NaN];
            Map = [transpose(clipShotBnds) transpose(matches)];
            
            %Optional : deletes all images in the current folder
            %              f = dir('*.jpg');
            %              files = {f.name};
            %              for k = 1:numel(files)
            %                delete(files{k});
            %              end
        end
        
        %   clipFrameIdxs = reverseMap(vidFrames, clipFrames, Correspondence)
        %   clipFrameIdxs should be m*1 vector, where m is the length of vidFrames.
        %   For each frame in vidFrame, give the corresponding index in clipFrames.
        %   If such a frame does not exist, put 'nan'
        function clipFrameIdxs = reverseMap(Map)
            %reverseMap  Maps every frame in the video to those in clip.
            % Does not do any actual comparisons but just linearly interpolates between the
            % shot boundaries from the map.
            clipFrameIdxs = zeros(Map(end),1);
            for k = 1:Map(2,2)
                clipFrameIdxs(k) = NaN;
            end
            for k = 2:(numel(Map(:,2))-2)
                slope = (Map(k+1,1)-Map(k,1))/(Map(k+1,2)-Map(k,2));
                for j = Map(k,2):Map(k+1,2)
                    clipFrameIdxs(j) = round(Map(k,1) + ((j-Map(k,2))*slope));
                end
            end
            for k = (Map(numel(Map)-1)+1):Map(end)
                clipFrameIdxs(k) = NaN;
            end
        end
        
        function SMap = getSMap(clipFrames, vidFrames,clipBnds,vidBnds)
            %getSMap Gets a matrix where the i,j'th element is (1 - Closeness(clipBnds(i),vidBnds(j)).
            
            %check if any boundary sets are empry. if so,
            %Create a new shot boundary matrix consisting of every element
            %in the frames.
            if numel(clipBnds) == 0
                clipBnds = 1:numel(clipFrames);
            end
            if numel(vidBnds) == 0
                vidBnds = 1:numel(vidFrames);
            end
            
            clipL = numel(clipBnds);
            vidL = numel(vidBnds);
            
            %Create a map to find the best match via ratios
            SMap = zeros(clipL,vidL);
            for i = 1:clipL
                for j = 1:vidL
                    SMap(i,j) = 1 - vidInspect.getCloseness(clipFrames{clipBnds(i)},vidFrames{vidBnds(j)},4);
                end
            end
            
        end
        
        function optCover= findOptCover(SMap, clipBnds, vidBnds)
            %findOptCover A version of getMap that uses dynamic time warping to run faster and more accurately
            
            f = size(SMap);
            GMap = zeros(f);
            MMap = cell(f);
            
            l = f(1);
            h = f(2);
            
            for i = 1:l
                for j = 1:h
                    
                    if j>1 && i == 1
                        if max(SMap(i,1:j)) ~= SMap(i,j)
                            GMap(i,j) = GMap(i,j-1);
                            MMap{1,j} = MMap{i,j-1};
                        else
                            GMap(i,j) = GMap(i,j-1) + SMap(i,j);
                            X = MMap{i,j-1};
                            X(end,:) = [];
                            MMap{i,j} = [X;[clipBnds(i) vidBnds(j)]];
                        end
                    elseif j>1 && i>= 2
                        
                        X = MMap{i-1,j};
                        
                        if max(SMap(i,1:j)) ~= SMap(i,j)
                            GMap(i,j) = GMap(i,j-1);
                            MMap{i,j} = MMap{i,j-1};
                        else
                            GMap(i,j) = GMap(i-1,j-1) + SMap(i,j);
                            X = MMap{i,j-1};
                            X(end,:) = [];
                            MMap{i,j} = [X;[clipBnds(i) vidBnds(j)]];
                        end
                        
                        Y = MMap{i,j};
                        Y = Y(end,:);
                        
                        MMap{i,j} = [X;Y];
                        
                    else
                        gs = 0;
                        
                        for k = 1:i
                            [g,I]= max(SMap(k,1:j));
                            gs = gs + g;
                            MMap{i,j} = [ MMap{i,j}; [clipBnds(k),vidBnds(I)] ];
                        end
                        
                        GMap(i,j) = gs;
                    end
                    
                end
            end
            
            if numel(clipBnds) == 1 || numel(vidBnds) == 1
                [~,a] = max(GMap);
                optCover = MMap{a};
            else
                [~,a,b] = vidInspect.max_matrix(GMap);
                optCover = MMap{a,b};
            end
            
            
            
        end
        
        function outSegs = getFrames(lowResFrms,segs,video,fps,outDir)
            
           mkdir(outDir);
           outDir = [outDir '/'];
           cmd = [vidInspect.FFmpegBin ' -i ' video ' -r ' num2str(fps) ' ' outDir 'image%5d.jpg'];
           system(cmd);
           
            f = dir(outDir);
            files = {f.name};
            vidFrms = cell(numel(files),1);
            for k = 4:numel(files)
                vidFrms{k} = imread([outDir '/' files{k}]);
            end
            vidFrms(1:3) = [];       

           segs = reshape( segs ,1,numel(segs));
           SMap = vidInspect.getSMap(lowResFrms,vidFrms,segs,1:numel(vidFrms));
           Map = vidInspect.findOptCover(SMap,segs,1:numel(vidFrms));
           outSegs = Map(:,2);
           outSegs = reshape(outSegs,2,numel(outSegs)/2);

        end
        
    end
    
end
