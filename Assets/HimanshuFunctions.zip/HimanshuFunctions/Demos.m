
% Author: Himanshu Kattelu
% Last updated: 6/19/15

%%%%%%%%%%%%%%%%%%%%%%%%%%% INSTRUCTIONS %%%%%%%%%%%%%%%%%%%%%%

%First off, Demoss.m and Testing.m must be in the same folder
%Next, make it so that ffmpeg can be run from your shell
%directly by setting ffmpeg/bin as an environment variable.
%Finally, get vl_feat and change the path of the below
%statement to the proper path of vl_setup
%(Although if you have vl_feat already permanently setup you can
% ignore this part completely)

run('C:\Users\himanshu\Downloads\vlfeat-0.9.20\toolbox\vl_setup')

% All the functions are currently commented out; if your want to run one of
% them simply un-comment it and then run the program. The main reason for
% this is because some of the functions can have long runtimes especially
% if they are extracting frames from a video.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DEMOS %%%%%%%%%%%%%%%%%%%%%%%%%%

% A function that takes in a clip and a video and finds the frame
% numbers inside the video where the clip begins and starts
% parameters are : (clip pathname, vid pathname, resolution Width,
% resolution Height, frames/second)
% The resolution options affect the accuracy while the fps affects the
% speed as this function extracts all the frames from the pathnames and
% comapres them.

% NOTE: There is a variant of this function which works with pre-extracted
% frames and is much faster called getMatchPointsF. It has parameters:
% (clip Frames, vid Frames, res Width, res Height)

% Testing.getMatchPoints('sample.mp4','ori.mp4',40,30,24);

%-------------------------------------------------------------------------

% A function that takes a video and extracts all of its frames into a cell
% array. parameters are (video pathname, fps, resolution)
% It is important to note that here the resolution is taken as a string of
% the form 'HeightxWidth'

% Frames = Testing.extractFrames('ori.mp4',24,'40x30');

%-------------------------------------------------------------------------

% A function that takes a video and clips part of it, placing a new video
% in the current folder. parameters are (startTime,endTime,vid pathname,
% output pathname).
% It is important to note that the start and end times of the clips are in
% seconds and they are written as strings.

% Testing.clipVid('20','60','ori.mp4','clip.mp4');

%-------------------------------------------------------------------------

% A function that takes in the frames of a video and a clip in the video,
% along with shot boundaries, and returns a map containing the
% correspondence of the shot boundaries to frame numbers inside the clip.
% parameters (video frames, clip frames, shot bounds, res width, res
% height)
% first column of output is the shot bounds in the video, the second column
% is the shot bounds in the clip 
% the resolution options are important to the speed of the program
% Additionally, a nice thing about this is that it can work with varying
% framerates as it depends only on the frames themselves

% NOTE: Output will not make sense if the shot bounds don't exist in the
% clip. Also this may take a while as it is required to extract the frames
% from both the video and clip in order to run the function.


%oriFrames = Testing.extractFrames('ori.mp4',30,'40x30');
%sampleFrames = Testing.extractFrames('sample.mp4',24,'40x30');
%shotBounds = [70 80 90];
% Map = Testing.getMap(oriFrames,sampleFrames,shotBnd,40,30);

%-------------------------------------------------------------------------

% A function that can take a map made by the previous function and a set of
% shot bounds and get the frame nubers of the shot bounds in the clip of
% the video.
%parameters( shot bounds, map )
%The shot bounds in this do not necessarily have to match those in the
%previous function.



%shotBnds = [70,90];
%ClipFrames = Testing.reverseMap(shotBnds, Map);











