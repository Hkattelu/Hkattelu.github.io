The videos provided are examples that you can use with the functions i wrote.

Ori.mp4 ~2min long   Resolution: 480 x 360
sample.mp4: a 30sec clip from ori.mp4  

Uncharted.mp4 ~10min long Resolution : 864 x 480
un.mp4: a 73 second clip from Uncharted.mp4