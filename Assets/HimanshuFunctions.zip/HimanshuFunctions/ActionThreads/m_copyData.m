% Copy data for Himanshu
% By: Minh Hoai Nguyen (minhhoai@cs.stonybrook.edu)
% Created: 28-Jul-2015
% Last modified: 28-Jul-2015

ids = [000011, 002960, 037677, 023160, 000716, 067587, 050854, 005024, 13124, 66992]; % list of ids to copy

for i=1:length(ids)
    id = ids(i);
    cmd = sprintf('cp -r ../ActionThreads/videos/%06d.mp4 ./videos/', id);
    fprintf('%s\n', cmd);
    system(cmd);
 
    cmd = sprintf('cp -r ../ActionThreads/anno/%06d.mat ./anno/', id);
    fprintf('%s\n', cmd);
    system(cmd);
    
    cmd = sprintf('cp -r ../ActionThreads/frames_tar/%06d.tar ./frames_tar/', id);
    fprintf('%s\n', cmd);
    system(cmd);
    
end

