
%Author: Himanshu Kattelu
%Last Updated 6/15/15

classdef Testing
    
    properties
    FFmpegBin = 'ffmpeg'
    end
   
   
   methods (Static) 
       
   %Takes an input file and and cuts out a clip at the given times
   %and puts the clip into an output file of a specified name
   function clipVid(start,finish,input,output)
    startTime = start;
    endTime = finish;
    inputFile = input;
    outputFile = output;

    cmd = ['ffmpeg -i ' inputFile ' -ss ' startTime ' -to ' endTime ' ' outputFile];
    system(cmd);
    end
  
   %Takes in two images, converts them to a resolution, then returns
   %their closeness. 5th input CELLSIZE determines size of HOG descriptor
   
   %im1x,im2x are images
   %resolutionW and resolutionH are width and height respectively
   %cellsize is the precision of the HOG descriptor
   function Closeness = getCloseness(im1x,im2x,resolutionW,resolutionH,cellsize)

    %Getting the two images ready
    
    im1r=imresize(im1x,[resolutionW,resolutionH]);
    im2r=imresize(im2x,[resolutionW,resolutionH]);
    
    %Converts images to singles for the HOG
    im1=im2single(im1r);
    im2=im2single(im2r);
    
    %Getting the HOGS
    hog1 = vl_hog( im1, cellsize, 'verbose');
    hog2 = vl_hog( im2, cellsize, 'verbose');
  
    %Computes and prints the Closeness
    ClosenessM = (abs(abs(hog2) - abs(hog1)));
    Closeness = sum(sum(sum(ClosenessM)))/(numel(ClosenessM));
    
    
   end 
   
   %Does the same thing as above but assumes the two img 
   %have the same resolution (speeds up the computation)
   function Closeness = getClosenessS(im1x,im2x,cellsize)
    
    %Converts images to singles for the HOG
    im1=im2single(im1x);
    im2=im2single(im2x);
    
    %Getting the HOGS
    hog1 = vl_hog( im1, cellsize, 'verbose');
    hog2 = vl_hog( im2, cellsize, 'verbose');
  
    %Computes and prints the Closeness
    ClosenessM = (abs(abs(hog2) - abs(hog1)));
    Closeness = sum(sum(sum(ClosenessM)))/(numel(ClosenessM));
    
    
   end 
   
   %Returns the start and end frames of a clip as images
   %Second parameter specifies length of the video for ffmpeg
   function Bounds = getBounds(clip)
       A = VideoReader(clip);
       cmdStart = ['ffmpeg -i ' clip ' -r 1 -vframes 1 start.jpg'];
       cmdEnd = ['ffmpeg -i ' clip ' -r 1 -vframes 1 -ss ' num2str(A.Duration - 0.1) ' end.jpg'];
       system(cmdStart);
       system(cmdEnd);
       
       Bounds{1} = imread('start.jpg');
       Bounds{2} = imread('end.jpg');
       delete('start.jpg','end.jpg');
   end
   
   %Extracts all frames from a video and places them into
   %a matrix.
   %fps should be written as a string
   %resolution should be written as string in format 'HxW'
   function Im = extractFrames(video,fps,res)
            
       cmd = ['ffmpeg -i ' video ' -r ' num2str(fps) ' -s ' res  ' image%3d.jpg'];
       system(cmd);
       f = dir('*.jpg');
       files = {f.name};
       Im = cell(numel(files),1);
       for k = 1:numel(files)
        Im{k} = imread(files{k});
        delete(files{k});
       end
       
   end
   
   %Creates an array containing the Closeness values of
   %the frame when compared to every frame in setOfFrames
   function Imranks = getRanks(frame,setOfFrames,resolutionW,resolutionH)
      Imranks = ones([1,numel(setOfFrames)]);
      for k = 1:numel(setOfFrames)
         Imranks(k) = Testing.getCloseness(frame,setOfFrames{k},resolutionW,resolutionH,1);
      end
   end
   
   %Does the same as the above, but implements a counter so that
   %the Imranks of multiple frames can be computed in shorter loops
   function Imranks = getRanksC(frame,setOfFrames,~,~,counter)
      Imranks = ones(1,numel(setOfFrames)-counter);
      for k = 1:numel(setOfFrames)-counter
         Imranks(k) = Testing.getClosenessS(frame,setOfFrames{k+counter},1);
      end
   end
   
   %Given a clip and a video, will find the start and end
   %frames that the clip is inside the video.
   %you can specifiy the fps that you want the video to be
   %read with, as well as the resolution to compare the two.
   function getMatchPoints(clip,video,resW,resH,fps)
       X = Testing.getBounds(clip);
       res = [num2str(resW) 'x' num2str(resH)];
       Im = Testing.extractFrames(video,fps,res);

       X1 = Testing.getRanks(X{1},Im,resW,resH);
       X2 = Testing.getRanks(X{2},Im,resW,resH);

       [~,startFrameMatch] = min(X1);
       [~,endFrameMatch] = min(X2);

       startFrameMatch
       endFrameMatch
   end
   
   %Does the same as the above, except with the frames themselves
   %so that the portion where frames are extracted is skipped
   function getMatchPointsF(clipFrames,vidFrames,resW,resH)
       X1 = Testing.getRanks(clipFrames{1},vidFrames,resW,resH);
       X2 = Testing.getRanks(clipFrames{numel(clipFrames)},vidFrames,resW,resH);

       [~,startFrameMatch] = min(X1);
       [~,endFrameMatch] = min(X2);

       startFrameMatch
       endFrameMatch
   end
   
   %Does the same thing as the above, but does it for a single frame
   function point = getMatchPoint(frame,videoFrames,resW,resH,counter)
     X = Testing.getRanksC(frame,videoFrames,resW,resH,counter);  
     [~,point] = min(X);
     point = point + counter;
   end
   
   %Maps the shot boundaries in the video to frames in the clip
   %The left column of the output shows the shot boundaries, and the
   %The right column shows the respective match in the clip
   %When inputting the vid and clip frames input them as cell arrays
   %input the shot boundaries as a row matrix
   %shot boundary numbers MUST be in increasing order
   function Correspondence = getMap(vidFrames,clipFrames,shotBnd,resW,resH)
       
       matches = ones(1,numel(shotBnd));
       A=1;
       for k = 1:numel(shotBnd)
           matches(k) = Testing.getMatchPoint(vidFrames{shotBnd(k)},clipFrames,resW,resH,A);
           A = matches(k);
       end
       
       startFrame = Testing.getMatchPoint(clipFrames{1},vidFrames,resW,resH,1);
       endFrame = Testing.getMatchPoint(clipFrames{numel(clipFrames)},vidFrames,resW,resH,startFrame);
       
       shotBnd = [startFrame ; transpose(shotBnd) ; endFrame];
       matches = [1 ;transpose(matches) ;numel(clipFrames)];
       Correspondence = [shotBnd matches];
   end
   
   function clipFrames = reverseMap(shotBnd,map)
       clipFrames = zeros(1,numel(shotBnd));
    for k = 1:numel(shotBnd)
        i = find(map == shotBnd(k));
        clipFrames(k) = map(i,2);
    end
    clipFrames = [1 clipFrames map(numel(map))];
   end
   
   end
   
   
   
end   
