%A set of functions which can be used to manipulate videos.
% Copyright (C) 2015 Himanshu Kattelu <himanshu.kattelu@stonybrook.edu>,
% Created : 15-June-2015
% Last Modified : 23-August-2015
% Requires vl_feat for HOG and SIFT

classdef vidInspect
    %vidInspect A set of functions which can be used to manipulate videos.
    %
    %Specifically, these functions can be used to compare videos or clips
    %as well as images. They can also be used to create mappings between
    %video frames to compare.
    %
    %vidInspect Properties:
    %    FFmpegBin - Pathname of ffmpeg/bin. Can be left as ffmpeg if ffmpeg is an environment variable.
    %
    %vidInspect Methods:
    %    clipVid - Takes an input file and and cuts out a clip at the given times
    %    extractFrames - Extracts all frames from a video and places them into a cell array
    %    findOptCover - A version of getMap that uses dynamic time warping to run faster and more accurately
    %    getBounds - Returns the start and end frames of a clip as images
    %    getCloseness - Compares two images and returns a number to represent the closeness
    %    getClosenessR - Does the same thing as getCloseness but assumes the two img have the same resolution (speeds up the computation)
    %    getMap - Maps the shot boundaries in the video to frames in the clip
    %    getMatchPoint - Does the same thing as the getMatchpointsR, except with only one frame to a set of frames
    %    getMatchPoints - Finds the start and end frames that the clip is located at inside the video.
    %    getMatchPointsR - Does the same as the getMatchPoints, except with the frames themselves
    %    getPaths - Extracts all frames from a video then returns a cell array with all pathnames
    %    getRanks - Creates a vector containing the Closeness values of frame when compared to every frame in setOfFrames
    %    getSMap - Gets a matrix where the i,j'th element is (1 - Closeness(clipBnds(i),vidBnds(j)).
    %    max_matrix - Returns the max element of a 2D matrix and it's indices
    %    reverseMap - Maps every frame in the video to those in clip.
    %    getFrames A function that takes in low res. frames, finds them in a video, and outputs the corresponding segments as well as the video frames
    
    properties (Constant)
        %Pathname of ffmpeg/bin. Can be left as ffmpeg if ffmpeg is an environment variable.
        FFmpegBin = 'ffmpeg'
    end
      
    methods (Static)
        
        function [val, x, y] = max_matrix(A)
            %max_matrix Returns the max element of a 2D matrix and it's indices
            %
            %Params: A is a 2D matrix of numbers
            
            [v, x1] = max(A);
            [val, y] = max(v);
            x = x1(y);
        end
        
        function clipVid(start,finish,input,output)
            %clipVid Takes an input file and and cuts out a clip at the given times
            %Puts the clip into an output file of a specified name
            %
            %Params: start is the start time (seconds), finish is finish
            %time (seconds), input is the input video pathname, output is
            %the output video pathname.
            
            cmd = [vidInspect.FFmpegBin ' -i ' input ' -ss ' num2str(start) ' -to ' num2str(finish) ' ' output];
            system(cmd);
        end
        
        function Closeness = getCloseness(im1x,im2x,cellsize)
            %getCloseness Compares two images and returns a number to represent the closeness
            %Takes in two images, converts them to the same resolution, then returns
            %their closeness.
            %
            %Params: im1x,im2x are images,cellsize is the precision of the HOG descriptor (The lower, the more precise)
            
            d1 = size(im1x);
            d2 = size(im2x);
            resolutionH = min([d1(1) d2(1)]);
            resolutionW = min([d1(2) d2(2)]);
            
            %Getting the two images ready
            im1r=imresize(im1x,[resolutionW,resolutionH]);
            im2r=imresize(im2x,[resolutionW,resolutionH]);
            
            %Converts images to singles for the HOG
            im1=im2single(im1r);
            im2=im2single(im2r);
            
            %Getting the HOGS
            hog1 = vl_hog( im1, cellsize, 'verbose');
            hog2 = vl_hog( im2, cellsize, 'verbose');
            
            %Computes and prints the Closeness
            ClosenessM = (abs(abs(hog2) - abs(hog1)));
            Closeness = mean(ClosenessM(:));
        end
        
        function Closeness = getClosenessR(im1x,im2x,cellsize)
            %getClosenessR Does the same thing as getCloseness but assumes the two img have the same resolution (speeds up the computation)
            %
            %Params: im1x,im2x are images,cellsize is the precision of the HOG descriptor (The lower, the more precise)
            
            %Converts images to singles for the HOG
            im1=im2single(im1x);
            im2=im2single(im2x);
            
            %Getting the HOGS
            hog1 = vl_hog( im1, cellsize, 'verbose');
            hog2 = vl_hog( im2, cellsize, 'verbose');
            
            %Computes and prints the Closeness
            ClosenessM = (abs(abs(hog2) - abs(hog1)));
            Closeness = mean(ClosenessM);
            
        end
        
        function Bounds = getBounds(clip,res)
            %getBounds Returns the start and end frames of a clip as images
            %
            %Params: clip is the pathname of the input clip. res is the
            %resolution in the form 'HeightxWidth'
            
            A = VideoReader(clip);
            cmdStart = [vidInspect.FFmpegBin ' -i ' clip ' -s ' res ' -r 1 -vframes 1 start.jpg'];
            cmdEnd = [vidInspect.FFmpegBin ' -i ' clip ' -s ' res ' -r 1 -vframes 1 -ss ' num2str(A.Duration - 0.1) ' end.jpg'];
            system(cmdStart);
            system(cmdEnd);
            
            Bounds{1} = imread('start.jpg');
            Bounds{2} = imread('end.jpg');
            delete('start.jpg','end.jpg');
        end
        
        function Im = extractFrames(video,fps,res)
            %extractFrames Extracts all frames from a video and places them into a cell array
            %
            %Params: video is the pathname of the input video. res is the
            %resolution in the form 'HeightxWidth'. fps is the desired
            %frames per second for the extracted frames
            %WARNING: If there are too many frames you may run out of memory.
                       
            cmd = [vidInspect.FFmpegBin ' -i ' video ' -r ' num2str(fps) ' -s ' res  ' image%5d.jpg'];
            system(cmd);
            f = dir('*.jpg');
            files = {f.name};
            Im = cell(numel(files),1);
            for k = 1:numel(files)
                Im{k} = imread(files{k});
                delete(files{k});
            end
            
        end
        
        function imFiles = getPaths(video,fps,res)
            %getPaths Extracts all frames from a video into the folder and then returns a cell array with all pathnames
            %
            %Params: video is the pathname of the input video. res is the
            %resolution in the form 'HeightxWidth'. fps is the desired
            %frames per second for the extracted frames

            cmd = [vidInspect.FFmpegBin ' -i ' video ' -r ' num2str(fps) ' -s ' res  ' image%5d.jpg'];
            system(cmd);
            f = dir('image*');
            imFiles = {f.name};
        end
        
        function Imranks = getRanks(frame,setOfFrames)
            %getRanks Creates a vector containing the Closeness values of frame when compared to every frame in setOfFrames
            %
            %Params: frame is an image from a video. setOfFrames is a cell
            %structure of images.
            Imranks = ones([1,numel(setOfFrames)]);
            for k = 1:numel(setOfFrames)
                Imranks(k) = vidInspect.getCloseness(frame,setOfFrames{k},2);
            end
        end
     
        function [startFrameMatch,endFrameMatch] = getMatchPoints(clip,video,resW,resH,fps)
            %getMatchPoints Finds the start and end frames that the clip is located at inside the video.
            %you can specifiy the fps that you want the video to be
            %read with, as well as the resolution to compare the two.
            %
            %Params: clip is the pathname of the clip. video is the
            %pathname of the video. resW and resH are the the width and
            %height respectively of the frames that will be extracted from
            %the clip (numbers, not strings). fps is the desired frames per
            %second of the frames being extracted from the clip.
            
            res = [num2str(resW) 'x' num2str(resH)];
            X = vidInspect.getBounds(clip,res);
            Im = vidInspect.extractFrames(video,fps,res);
            
            X1 = vidInspect.getRanks(X{1},Im);
            X2 = vidInspect.getRanks(X{2},Im);
            
            [~,startFrameMatch] = min(X1);
            [~,endFrameMatch] = min(X2);
            
        end
        
        function [startFrameMatch,endFrameMatch] = getMatchPointsR(clipFrames,vidFrames)
            %getMatchPointsR Does the same as the getMatchPoints, except with the frames themselves
            %
            %Params: clipFrames is a cell structure of images from the clip. videoFrames is a cell
            %structure of images from the full video.
            
            X1 = vidInspect.getRanks(clipFrames{1},vidFrames);
            X2 = vidInspect.getRanks(clipFrames{end},vidFrames);
            
            [~,startFrameMatch] = min(X1);
            [~,endFrameMatch] = min(X2);
            
        end
        
        function point = getMatchPoint(frame,videoFrames)
            %getMatchPoint Does the same thing as the getMatchpointsR, except with only one frame to a set of frames
            %
            %Params: frame is an image from a video. videoFrames is a cell
            %structure of images.
            X = vidInspect.getRanks(frame,videoFrames);
            [~,point] = min(X);
        end

        function I = getDoubleMatchPoint(frames,videoFrames)
            %getDoubleMatchPoint Does the same thing as the getMatchpoint, except with a pair of consecutive frames to a set of frames
            %Returns the match point of the first of the two frames. The
            %second match point will be 1 + the first one.
            %
            %Params: frames is a cell structure containing two consecutive images from a video. videoFrames is a cell
            %structure of images.
            X = vidInspect.getRanks(frames{1},videoFrames);
            Y = vidInspect.getRanks(frames{2},videoFrames);
            Y(end + 1) = 0;
            Y(1) = [];
            Z = X + Y;
            [~,I] = min(Z);
        end
        
        function Map = getMap(vidFrames,clipFrames,clipShotBnds,vidShotBnds)
            %getMap Maps the shot boundaries in the video to frames in the clip
            %The left column of the output shows the shot boundaries, and the
            %The right column shows the respective match in the clip
            %input the shot boundaries as a row matrix  in increasing order
            %
            %Params: clipFrames is a cell structure of images from the clip. videoFrames is a cell
            %structure of images from the full video. clipShotBnds is a
            %1xN matrix containing the frame numbers of the shot boundaries
            %of the clip. vidShotBnds is 1xN matrix containing the frame numbers of the shot boundaries
            %of the video.
            matches = zeros(1,numel(clipShotBnds));
            numBounds = numel(vidShotBnds);
            vidShotBnds = num2cell(vidShotBnds);
            vidShotFrames = cell(1,numBounds);
            for k = 1:numBounds
                vidShotFrames{k}  = vidFrames{vidShotBnds{k}};
            end
            
            for k = 1:numel(clipShotBnds)
                clipFrame = clipFrames{clipShotBnds(k)};
                matchpt = vidInspect.getMatchPoint(clipFrame,vidShotFrames);
                matches(k) = vidShotBnds{matchpt};
            end

            Map = [transpose(clipShotBnds) transpose(matches)];
            

        end
        
        %   clipFrameIdxs = reverseMap(vidFrames, clipFrames, Correspondence)
        %   clipFrameIdxs should be m*1 vector, where m is the length of vidFrames.
        %   For each frame in vidFrame, give the corresponding index in clipFrames.
        function clipFrameIdxs = reverseMap(Map)
            %reverseMap  Maps every frame in the video to those in clip.
            % Does not do any actual comparisons but just linearly interpolates between the
            % shot boundaries from the map.
            %
            % Params: Map is a 2xN matrix containing the Map obtained from
            % function getMap. The first column contains the shot
            % boundaries in the clip and the second contains their
            % equivalents in the video.
            clipFrameIdxs = zeros(Map(end),1);
            for k = 1:Map(2,2)
                clipFrameIdxs(k) = NaN;
            end
            for k = 1:(numel(Map(:,2))-1)
                slope = (Map(k+1,1)-Map(k,1))/(Map(k+1,2)-Map(k,2));
                for j = Map(k,2):Map(k+1,2)
                    clipFrameIdxs(j) = round(Map(k,1) + ((j-Map(k,2))*slope));
                end
            end
            for k = (Map(numel(Map)-1)+1):Map(end)
                clipFrameIdxs(k) = NaN;
            end
        end
        
        function SMap = getSMap(clipFrames, vidFrames,clipBnds,vidBnds)
            %getSMap Gets a matrix where the i,j'th element is (1 - Closeness(clipBnds(i),vidBnds(j)).
            %
            %Params: clipFrames is a cell structure of images from the clip. vidFrames is a cell
            %structure of images from the full video. clipBnds is a
            %1xN matrix containing the frame numbers of the shot boundaries
            %of the clip. vidBnds is 1xN matrix containing the frame numbers of the shot boundaries
            %of the video.
            
            %Check if any boundary sets are empty. if so,
            %create a new shot boundary matrix consisting of every element
            %in the frames.
            if numel(clipBnds) == 0
                clipBnds = 1:numel(clipFrames);
            end
            if numel(vidBnds) == 0
                vidBnds = 1:numel(vidFrames);
            end
            
            clipL = numel(clipBnds);
            vidL = numel(vidBnds);
            
            %Create a map to find the best match via ratios
            SMap = zeros(clipL,vidL);
            for i = 1:clipL
                for j = 1:vidL
                    SMap(i,j) = 1 - vidInspect.getCloseness(clipFrames{clipBnds(i)},vidFrames{vidBnds(j)},4);
                end
            end
            
        end
        
        function optCover= findOptCover(SMap, clipBnds, vidBnds)
            %findOptCover A version of getMap that uses dynamic time warping to run faster and more accurately
            %
            %Params: SMap is a map containing image closeness values
            %retreieved from calling .getSMap(). clipBnds is a 1xN matrix containing the frame numbers of the shot boundaries
            %of the clip. vidBnds is 1xN matrix containing the frame numbers of the shot boundaries of the video.
            f = size(SMap);
            GMap = zeros(f);
            MMap = cell(f);
            
            l = f(1);
            h = f(2);
            
            for i = 1:l
                for j = 1:h
                    
                    if j>1 && i == 1
                        if max(SMap(i,1:j)) ~= SMap(i,j)
                            GMap(i,j) = GMap(i,j-1);
                            MMap{1,j} = MMap{i,j-1};
                        else
                            GMap(i,j) = GMap(i,j-1) + SMap(i,j);
                            X = MMap{i,j-1};
                            X(end,:) = [];
                            MMap{i,j} = [X;[clipBnds(i) vidBnds(j)]];
                        end
                    elseif j>1 && i>= 2
                        
                        X = MMap{i-1,j};
                        
                        if max(SMap(i,1:j)) ~= SMap(i,j)
                            GMap(i,j) = GMap(i,j-1);
                            MMap{i,j} = MMap{i,j-1};
                        else
                            GMap(i,j) = GMap(i-1,j-1) + SMap(i,j);
                            X = MMap{i,j-1};
                            X(end,:) = [];
                            MMap{i,j} = [X;[clipBnds(i) vidBnds(j)]];
                        end
                        
                        Y = MMap{i,j};
                        Y = Y(end,:);
                        
                        MMap{i,j} = [X;Y];
                        
                    else
                        gs = 0;
                        
                        for k = 1:i
                            [g,I]= max(SMap(k,1:j));
                            gs = gs + g;
                            MMap{i,j} = [ MMap{i,j}; [clipBnds(k),vidBnds(I)] ];
                        end
                        
                        GMap(i,j) = gs;
                    end
                    
                end
            end
            
            if numel(clipBnds) == 1 || numel(vidBnds) == 1
                [~,a] = max(GMap);
                optCover = MMap{a};
            else
                [~,a,b] = vidInspect.max_matrix(GMap);
                optCover = MMap{a,b};
            end
            
        end
        
        function [Start,End] = findSegs(shotBnds,seg)
        %findSegs A function that takes in a segment and finds which index
        %of shotBnds that the seg is in between
        %
        %Params: seg is a number in between 1 and shotBnds(n), shotBnds is
        %a 1xN matrix containing increasing numbers where the first element must
        %be a 1 and the last element is greater than or equal to 2.
        
            Start = shotBnds(1);
            End = shotBnds(1);
         if numel(shotBnds) >= 2
           for i = 1:numel(shotBnds)-1
               if seg < shotBnds(i+1)
                   Start = i;
                   End = i+1;            
               end
           end
         end   
        end
        
        function outSegs = getFrames(lowResFrms,shotBnds,segs,video,fps,outDir)
        %getFrames A function that takes in low res. frames, finds them in a video, and outputs the corresponding segments as well as the video frames
        %
        %Params: lowResFrms is a cell structure of low resolution images,shotBnds is a 2xN matrix containing the shot boundaries of the lowResFrms and is a subset of segs,
        %segs is a 2xN matrix containing the set of segments in the video , video is the pathname of the video in the folder, fps is the desired frames per second
        %of video, outDir is the name of the output directory for the video frames.
            
           mkdir(outDir);
           outDir = [outDir '/'];
           cmd = [vidInspect.FFmpegBin ' -i ' video ' -r ' num2str(fps) ' ' outDir 'image%5d.jpg'];
           system(cmd);
           
            f = dir(fullfile(outDir,'*.jpg'));
            files = {f.name};
            vidFrms = cell(numel(files),1);
            for k = 1:numel(files)
                vidFrms{k} = imread([outDir '/' files{k}]);
            end
            
           ratio = numel(vidFrms)/numel(lowResFrms);  
           vidShotBnds = ML_VidShot.detectCuts(vidFrms);     
           segs = reshape(segs ,1,numel(segs));
           n = numel(segs);
           shotBnds = shotBnds(1,:);
           outSegs = zeros(1,n);
         
         %Compute map based on number of shot bounds in each set  
           if numel(vidShotBnds) < numel(shotBnds)
             shotBndMap = vidInspect.getMap(lowResFrms,vidFrms,vidShotBnds,shotBnds);
           elseif numel(vidShotBnds) == numel(shotBnds)
             shotBndMap = [vidShotBnds, shotBnds];
           else
             tempMap = vidInspect.getMap(vidFrms,lowRes,Frms,shotBnds,vidShotBnds);
             shotBndMap = [tempMap(2,:) tempMap(1,:)];
           end
          
           for i = 1:numel(shotBndMap(:,1))
              k = find(segs == shotBndMap(i,2));
              if (k==1)
                  k =3;
              end
              outSegs(k) = shotBndMap(i,1);
              outSegs(k-1) = outSegs(k) - 1;
           end
           
           outSegs(1) = 1;
           outSegs(n) = numel(vidFrms);
           for k = 1:numel(outSegs)
              if outSegs(k) ~= 0
              else
                  frames = {lowResFrms{segs(k)},lowResFrms{segs(k+1)}};
                  c = ceil(segs(k) * ratio);
                  [startIndex,endIndex] = vidInspect.findSegs(vidShotBnds,c);
                  cutFrms = vidFrms(vidShotBnds(startIndex):vidShotBnds(endIndex));         
                  point = vidShotBnds(startIndex)-1+vidInspect.getDoubleMatchPoint(frames,cutFrms);
                  outSegs(k) = point;
                  outSegs(k+1) = point + 1;
              end
           end  
          
           outSegs = reshape(outSegs,2,numel(outSegs)/2);
           
        end
        
        function outSegs = getFramesExisting(lowResFrms,shotBnds,segs,vidFrms)
        %getFramesExisting A version of .getFrames that works when the
        %video frames have already been extracted to save time.
        %
        %Params: lowResFrms is a cell structure of low resolution images,shotBnds is a 2xN matrix containing the shot boundaries of the lowResFrms and is a subset of segs,
        %segs is a 2xN matrix containing the set of segments in the video , vidDir is the name of the directory containing the video frames.
            

           ratio = numel(vidFrms)/numel(lowResFrms);  
           vidShotBnds = ML_VidShot.detectCuts(vidFrms);     
           segs = reshape(segs ,1,numel(segs));
           n = numel(segs);
           shotBnds = shotBnds(1,:);
           outSegs = zeros(1,n);
           
           if numel(vidShotBnds) < numel(shotBnds)
             shotBndMap = vidInspect.getMap(lowResFrms,vidFrms,vidShotBnds,shotBnds);
           elseif numel(vidShotBnds) == numel(shotBnds)
             shotBndMap = [vidShotBnds, shotBnds];
           else
             tempMap = vidInspect.getMap(vidFrms,lowRes,Frms,shotBnds,vidShotBnds);
             shotBndMap = [tempMap(2,:) tempMap(1,:)];
           end
           
           for i = 1:numel(shotBndMap(:,1))
              k = find(segs == shotBndMap(i,2));
              if (k==1)
                  k =3;
              end
              outSegs(k) = shotBndMap(i,1);
              outSegs(k-1) = outSegs(k) - 1;
           end
           
           outSegs(1) = 1;
           outSegs(n) = numel(vidFrms);
           
           for k = 1:numel(outSegs)
              if outSegs(k) ~= 0
              else
                  frames = {lowResFrms{segs(k)},lowResFrms{segs(k+1)}};
                  c = ceil(segs(k) * ratio);
                  [startIndex,endIndex] = vidInspect.findSegs(vidShotBnds,c)
                  cutFrms = vidFrms(vidShotBnds(startIndex):vidShotBnds(endIndex));         
                  point = vidShotBnds(startIndex)-1+vidInspect.getDoubleMatchPoint(frames,cutFrms);
                  outSegs(k) = point;
                  outSegs(k+1) = point + 1;
              end
           end  
          
           outSegs = reshape(outSegs,2,numel(outSegs)/2);
           
        end
        
        function dispImgPlot(Map,frames1,frames2,directoryName,shotBnds)
          %dispImgPlot Creates a directory containing an html doc with the images from frames1
          %and frames2 that correspond with the frame numbers in Map.
          %  
          % Params: Map is a 2xN matrix containing the Map obtained from
          % function getMap. The first column contains the shot
          % boundaries in the clip and the second contains their
          % equivalents in the video. frames1 and frames2 are cell
          % structures containing video frames.
          
          mkdir(directoryName)
          x = numel(Map(:,1)); 
          data = fopen([directoryName '/data.html'],'w');
          for k = 1:x
             if Map(k,1) == 0
             else
             y1 = sprintf('image1%03d.jpeg',k);         
             imwrite(frames1{Map(k,1)},[directoryName '/' y1])
             end
             if Map(k,2) == 0
             else
             y2 = sprintf('image2%03d.jpeg',k) ;
             imwrite(frames2{Map(k,2)},[directoryName '/' y2])
             end
          end

          for l = 1:x
          z1 = sprintf('image1%03d.jpeg',l);
          z2 = sprintf('image2%03d.jpeg',l);
          img1 = ['<img src = "'  z1 '" >'];
          img2 = ['<img src = "'  z2 '" >'];
          if any(find(Map(l,1) == shotBnds)) == 1
              type = 'shotBnd';
          else
              type = 'seg';
          end
          type = [ type ' ' num2str(Map(l,1)) ' ' num2str(Map(l,2))];   
          
          string = ['<p>' img1 img2 type '</p>'];

          fprintf(data,string);
          fprintf(data,'<br> \n');
          end
          fclose('all');
          open([directoryName '/data.html']);
          
        end
    
        
    end
    
end
