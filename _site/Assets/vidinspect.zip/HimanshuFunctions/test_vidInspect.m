% A set of test functions for vidInspect.m
% Copyright (C) 2015 Himanshu Kattelu <himanshu.kattelu@stonybrook.edu>,
% Created : 19-June-2015
% Last Modified : 23-August-2015
% Requires vl_feat for HOG and SIFT

classdef test_vidInspect
    
    methods (Static)
        
        function [Map,lowresFrms,vidFrms] = test_1(anno,frames,video,desFPS,outDir,plotDir)
           
            tic;
            %Getting segments
            m = matfile(anno);
            segs = m.segs; 
            shots = m.shots;

            %Getting Low res frames
            Direc = frames;
            f = dir(fullfile(Direc,'*.jpg'));
            files = {f.name};
            lowresFrms = cell(numel(files),1);
            for k = 1:numel(files)
                lowresFrms{k} = imread([Direc '/' files{k}]);
            end
            
            segs(end) = numel(lowresFrms);
            outSegs = vidInspect.getFrames(lowresFrms,shots,segs,video,desFPS,outDir);

            Direc = outDir;
            f = dir(fullfile(Direc,'*.jpg'));
            files = {f.name};
            vidFrms = cell(numel(files),1);
            for k = 1:numel(files)
                vidFrms{k} = imread([Direc '/' files{k}]);
            end

            segs = reshape(segs,1,numel(segs));
            outSegs = reshape(outSegs,1,numel(outSegs));
            Map = [segs ; outSegs];
            Map = transpose(Map);

            vidInspect.dispImgPlot(Map,lowresFrms,vidFrms,plotDir,shots)
            toc
            
        end
        
        function test_2(Map,frames1,frames2,N)
           
             subplot(2,3,1)
             imshow(frames1{Map(N,1)})
             axis fill
             set(gca,'YTick',[])
             set(gca,'XTick',[])
             
             ax1 = subplot(2,3,2);
             closeness = vidInspect.getCloseness(frames1{Map(N,1)},frames2{Map(N,2)},4);
             score = sprintf('The distance is %4f', closeness);
             text(0, 0.5, score);
             set ( ax1, 'visible', 'off')
             
             subplot(2,3,3)
             imshow(frames2{Map(N,1)})
             axis fill
             set(gca,'YTick',[])
             set(gca,'XTick',[])
             
             subplot(2,3,4)
             imshow(frames1{Map(N,1) + 1})
             axis fill
             set(gca,'YTick',[])
             set(gca,'XTick',[])
             
             ax2 = subplot(2,3,5);
             closeness = vidInspect.getCloseness(frames1{Map(N,1)+1},frames2{Map(N,2) + 1},4);
             score = sprintf('The distance is %4f', closeness);
             text(0, 0.5, score);
             set ( ax2, 'visible', 'off')
             
             subplot(2,3,6)
             imshow(frames2{Map(N,2)+1})
             axis fill
             set(gca,'YTick',[])
             set(gca,'XTick',[])
            
        end
        
         function [Map,lowresFrms,vidFrms] = test_3(anno,frames,vidDir,plotDir)
           
            tic;
            %Getting segments
            m = matfile(anno);
            segs = m.segs; 
            shots = m.shots;

            %Getting Low res frames
            Direc = frames;
            f = dir(fullfile(Direc,'*.jpg'));
            files = {f.name};
            lowresFrms = cell(numel(files),1);
            for k = 1:numel(files)
                lowresFrms{k} = imread([Direc '/' files{k}]);
            end
         
            Direc = vidDir;
            f = dir(fullfile(Direc,'*.jpg'));
            files = {f.name};
            vidFrms = cell(numel(files),1);
            for k = 1:numel(files)
                vidFrms{k} = imread([Direc '/' files{k}]);
            end
            
            segs(end) = numel(lowresFrms);
            outSegs = vidInspect.getFramesExisting(lowresFrms,shots,segs,vidFrms);

            segs = reshape(segs,1,numel(segs));
            outSegs = reshape(outSegs,1,numel(outSegs));
            Map = [segs ; outSegs];
            Map = transpose(Map);
            
            vidInspect.dispImgPlot(Map,lowresFrms,vidFrms,plotDir,shots)
            toc
            
        end
    end
end