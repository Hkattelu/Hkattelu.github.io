% A set of demo functions for vidInspect.m
% Copyright (C) 2015 Himanshu Kattelu <himanshu.kattelu@stonybrook.edu>,
% Created : 19-June-2015
% Last Modified : 3-August-2015
% Requires vl_feat for HOG and SIFT

%%%%%%%%%%%%%%%%%%%%%%%%%%% INSTRUCTIONS %%%%%%%%%%%%%%%%%%%%%%

% First off, demo_vidInspect.m,vidInspect.m, and ML_VidShot.m must be in the same folder
% Next, make it so that ffmpeg can be run from your shell
% directly by setting ffmpeg/bin as an environment variable.
% Finally, install vl_feat 

%Additionally, try to run the demos one at a time as some may have long runtimes.

%To run DEMO 6 you must first extract 005024.tar.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DEMOS %%%%%%%%%%%%%%%%%%%%%%%%%%


classdef demo_vidInspect
  %A Class containing demo functions for the vidInspect class.
        
    methods (Static)
        
        function demo_1()
         % A function that takes in a clip and a video and finds the frame where the clip begins and ends
            % parameters are : (clip pathname, vid pathname, resolution Width,
            % resolution Height, frames/second)
            % The resolution options affect the accuracy while the fps affects the
            % speed as this function extracts all the frames from the pathnames and
            % comapres them.

            % NOTE: There is a variant of this function which works with pre-extracted
            % frames and is much faster called getMatchPointsR. It has parameters:
            % (clip Frames, vid Frames)
            
             tic;
             [startPt,endPt] = vidInspect.getMatchPoints('sample.mp4','ori.mp4',40,30,24)
             toc
            
        end
        
        function demo_2()
%             A function that takes a video and extracts all of its frames into a cell array. 
%             parameters are (video pathname, fps, resolution)
%             It is important to note that here the resolution is taken as a string of
%             the form 'HeightxWidth'

            Frames = vidInspect.extractFrames('ori.mp4',24,'40x30')
            
        end
        
        function demo_3()
       % A function that takes a video and clips part of it, placing a new video in the current folder. 
       % parameters are (startTime,endTime,vid pathname,output pathname).
        % The start and end times of the clip is in seconds 

        vidInspect.clipVid(20,60,'ori.mp4','clip.mp4');
            
        end
        
        function demo_4()
           %Two functions, one will get a map corresponding between the shot bounds
            % in the video and those in the clip. The second uses that map and 
            % linearly interpolates between the shot boundaries to get a match for
            % every single frame in the video to the clip (NaN if it does not exist)

            %For the getMap
            % first column of output is the shot bounds in the clip, the second column
            % is the shot bounds in the video
            % the resolution options are important to the speed of the program
            % Additionally, a nice thing about this is that it can work with varying
            % framerates as it depends only on the frames themselves

            %For reverseMap
            % creates an nx1 array where the kth element is the frame number of the
            % clip that matches to the kth frame in the video. NaN if that frame does
            % not exist in the clip.

            %Extract frames from clip and video

            vidFrames = vidInspect.extractFrames('ori.mp4',10,'40x30');
            clipFrames = vidInspect.extractFrames('sample.mp4',10,'480x360');

            %Detects shot boundaries and creates the mapping
 
            clipShtBnds = ML_VidShot.detectCuts(clipFrames);
            vidShtBnds = ML_VidShot.detectCuts(vidFrames);

            Map1 = vidInspect.getMap(vidFrames,clipFrames,clipShtBnds,vidShtBnds)

            %Gets the Map from the video frames to the clip frames(fast)

            Map2 = vidInspect.reverseMap(Map1)
            
            
        end
        
        function demo_5()
            %A function that uses dynamic time warping to build up the map from demo4
            %Faster and more accurate than the first function for large sets of shot boundaries
            %For smaller sets it can be less accurate and also slower than
            %the original.
            
            %Getting frames and shot boundaries
             vidFrms = vidInspect.extractFrames('ori.mp4',30,'40x30');  
             clipFrms = vidInspect.extractFrames('sample.mp4',24,'480x360');
             clipShotBnds = ML_VidShot.detectCuts(clipFrms);
             vidShotBnds = ML_VidShot.detectCuts(vidFrms);
            
            %Finding map with getMap() 
            tic;
            Map = vidInspect.getMap(vidFrms,clipFrms,clipShotBnds,vidShotBnds);
            t1 = toc;
            
            %Finding map with findOptCover() [Dynamic time warping]
            tic;
            SMap = vidInspect.getSMap(clipFrms,vidFrms,clipShotBnds,vidShotBnds);
            MapDTW = vidInspect.findOptCover(SMap,clipShotBnds,vidShotBnds)
            t2 = toc;
            
            Map
            
            fprintf('Time taken without dtw: %f \n',t1);
            fprintf('Time taken with dtw: %f \n',t2);
            
        end
        
        function demo_6()
         %getFrames will take in low resolution frames and a high resolution video along with segments,
         %and find the locations of the segments from the low res in the high res.
         %parameters: getFrames(low res Frames, segments, video, desired FPS, output directory for vidoe frames)
         % segments must be in the form of a 2xN matrix
         
         %Getting segments
            m = matfile('ActionThreads/anno/005024.mat');
            segs = m.segs; 
            shots = m.shots;
         %Getting Low res frames
            Direc = 'ActionThreads/frames_tar/005024';
            f = dir(Direc);
            files = {f.name};
            lowresFrms = cell(numel(files),1);
            for k = 4:numel(files)
                lowresFrms{k} = imread([Direc '/' files{k}]);
            end
            lowresFrms(1:3) = [];

            tic;
            outSegs5024 = vidInspect.getFrames(lowresFrms,segs,'ActionThreads/videos/005024.mp4',30,'5024')
            segs
            toc

            
        end
        
    end
    
end


 







